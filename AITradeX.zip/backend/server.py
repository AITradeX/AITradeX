from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/signal')
def signal():
    return jsonify({
        'currency': 'BTC',
        'target': '75000',
        'stoploss': '69000',
        'reason': 'Strong breakout with volume surge'
    })

if __name__ == '__main__':
    app.run()
