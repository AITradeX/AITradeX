function getSignal() {
  const signals = [
    { currency: "BTC/USDT", target: "$72,000", stoploss: "$67,500", reason: "Bullish breakout pattern" },
    { currency: "ETH/USDT", target: "$4,000", stoploss: "$3,500", reason: "Support bounce with volume" },
    { currency: "SOL/USDT", target: "$180", stoploss: "$155", reason: "Trendline retest" }
  ];

  const randomSignal = signals[Math.floor(Math.random() * signals.length)];
  document.getElementById("signal-output").innerHTML = `
    <h2>🚀 Trade Signal</h2>
    <p><strong>Pair:</strong> ${randomSignal.currency}</p>
    <p><strong>Target:</strong> ${randomSignal.target}</p>
    <p><strong>Stoploss:</strong> ${randomSignal.stoploss}</p>
    <p><strong>Reason:</strong> ${randomSignal.reason}</p>
  `;
}
